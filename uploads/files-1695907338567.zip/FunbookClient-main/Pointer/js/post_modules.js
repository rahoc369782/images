var count = 0;
var previous_position = 0;
const profile_module = (function () {
  function animated_scroll() {
    console.log(document.body, document.body.scrollTop);
    if (
      document.body.scrollTop > 350 ||
      document.documentElement.scrollTop > 350
    ) {
      document.getElementById("myImg").className = "slideUp";
    }
  }
  return {
    Hello: "Hello",
    animated_scroll,
  };
})();

function animated_scroll() {
  console.log(document.body, document.scrollTop);
  if (
    document.body.scrollTop > 350 ||
    document.documentElement.scrollTop > 350
  ) {
    document.getElementById("myImg").className = "slideUp";
  }
}

const main_feed_scroller = document.querySelector(".main_root");
const tab_header = document.querySelector(".mobile_header_two");
document.addEventListener("scroll", (event) => {
  if (window.scrollY && window.scrollY > previous_position) {
    // tab_header.style.display = "none";
    tab_header.classList.add("tab_header_transition_hide");
    tab_header.classList.remove("tab_header_transition_show");
  } else if (window.scrollY < previous_position) {
    tab_header.classList.add("tab_header_transition_show");
    tab_header.classList.remove("tab_header_transition_hide");
  }
  previous_position = window.scrollY;
});

function grab(type, entity) {
  let node;
  switch (type) {
    case "class":
      console.log(entity);
      node = document.getElementsByClassName(entity)[0];
      break;
    case "id":
      node = document.getElementById(entity);
      break;
    case "selector":
      node = document.querySelector(entity);
      break;
  }
  return node;
}

let posts = [
  {
    user: {
      name: "Rahul Darekar",
      introduction: "Scoder",
      userid: 1,
      user_profile:
        "https://arc-anglerfish-washpost-prod-washpost.s3.amazonaws.com/public/JTMO7OHDK4I6XCGFJ7LDQLCHZM.jpg",
    },
    post_meta_data: {
      one_word: "Stockers",
      specially_for: "About an IPO market",
      text_content:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quam ipsum, augue vulputate pretium morbi nec cras. Eget turpis tortor neque elementum fusce in.  porttitor viverra mattis sit odio viverra est. Tempor pharetra, ultricies leo, sagittis netus.",
      media_content:
        "https://arc-anglerfish-washpost-prod-washpost.s3.amazonaws.com/public/JTMO7OHDK4I6XCGFJ7LDQLCHZM.jpg",
      post_date: "4 hours ago",
    },
    post_stats: { likes: 100, helpfull: 50, shares: 190 },
  },
];
function create() {
  const container = grab("class", "sub_pointer_feed_container");

  for (let i = 0; i < 1; i++) {
    let post_parent_container = document.createElement("div");
    let post_parent_sub_container = document.createElement("div");
    let post_textual_data_container = document.createElement("div");
    let one_word_data_container = document.createElement("div");
    let post_owner_header = document.createElement("div");
    let post_owner_header_section1 = document.createElement("div");
    let post_owner_header_section2 = document.createElement("div");
    let post_owner_header_section3 = document.createElement("div");
    let core_posts_field = document.createElement("div");
    let profile_image = document.createElement("img");
    let one_word_pointer = document.createElement("img");
    let user_name = document.createElement("text");
    let user_introduction = document.createElement("span");
    let user_post_date = document.createElement("span");
    let post_textual_content = document.createElement("p");
    let post_one_word = document.createElement("a");
    let post_specially_for = document.createElement("p");
    let post_media_content = document.createElement("img");
    post_textual_content.classList.add("post_textual_content");
    post_one_word.classList.add("post_one_word");
    user_introduction.classList.add("user_introduction");
    post_parent_container.classList.add("post_parent_container");
    post_specially_for.classList.add("post_specially_for");
    post_textual_data_container.classList.add("post_textual_data_container");
    user_post_date.classList.add("user_post_date");
    one_word_data_container.classList.add("one_word_data_container");
    // user name
    user_name.textContent = posts[i].user["name"];
    user_introduction.textContent = posts[i].user["introduction"];
    profile_image.setAttribute("src", posts[i].user.user_profile);
    post_one_word.setAttribute("href", "https://forbes.com");
    post_one_word.setAttribute("target", "_blank");
    one_word_pointer.setAttribute("src", "../arrow.svg");
    post_one_word.textContent = posts[i].post_meta_data.one_word;
    user_name.classList.add("user_name");
    profile_image.classList.add("user_profile_image");

    //post
    post_textual_content.textContent = posts[i].post_meta_data["text_content"];
    user_post_date.textContent = ` . ${posts[i].post_meta_data["post_date"]}`;
    post_one_word.textContent = posts[i].post_meta_data["one_word"];
    post_specially_for.textContent = posts[i].post_meta_data["specially_for"];
    post_media_content.setAttribute(
      "src",
      posts[i].post_meta_data["media_content"]
    );
    post_owner_header.classList.add("post_owner_header");
    post_media_content.classList.add("post_media_content");
    post_owner_header_section3.classList.add("post_owner_header_section3");

    post_parent_container.append(post_textual_content);

    post_owner_header_section3.append(profile_image);
    post_owner_header_section1.append(user_name);
    post_owner_header_section2.append(user_introduction);
    post_owner_header_section2.append(user_post_date);
    one_word_data_container.append(post_one_word);
    one_word_data_container.append(one_word_pointer);
    post_owner_header_section1.append(post_owner_header_section2);
    post_owner_header_section3.append(post_owner_header_section1);
    post_owner_header.append(post_owner_header_section3);
    post_owner_header.append(one_word_data_container);

    core_posts_field.append(post_specially_for);
    core_posts_field.append(post_textual_content);

    post_textual_data_container.append(post_owner_header);
    post_textual_data_container.append(core_posts_field);
    post_parent_sub_container.append(post_textual_data_container);
    post_parent_sub_container.append(post_media_content);

    post_parent_container.appendChild(post_parent_sub_container);
    container.append(post_parent_container);
  }
}

function switch_mode() {
  const mode_status = document.getElementsByClassName("switch");
  if (mode_status.length === 0) {
    document.getElementsByClassName("main_root")[0].classList.add("switch");
  } else {
    document.getElementsByClassName("main_root")[0].classList.remove("switch");
  }
}
class Profile {
  constructor(name) {
    this.name = name;
  }

  change_name = (name) => {
    console.log(name);
  };
}
