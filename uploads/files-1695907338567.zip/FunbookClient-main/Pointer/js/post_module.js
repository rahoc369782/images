var count = 0
const profile_module = (function () {
  function render_post(data) {
    return {
      data,
    };
  }
  return {
    Hello: "Hello",
    render_post,
  };
})();

function create(data) {
  const container = document.getElementsByClassName("sub_pointer_feed_container")[0]
  for (let i = 0; i < 100; i++) {
    let new_element = document.createElement('div')
    new_element.append(document.createElement('p').textContent = `data ${count}`)
    count++
    container.append(new_element)
  }
}


class Profile {
  constructor(name) {
    this.name = name;
  }

  change_name = (name) => {
    console.log(name);
  };
}
