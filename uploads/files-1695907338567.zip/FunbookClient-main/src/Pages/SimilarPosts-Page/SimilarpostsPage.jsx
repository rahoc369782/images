import React, { Component } from "react";
import "./Similarposts.scss";
import { OriginalPostComponent } from "../../SmallComponents/OriginalPost-Component/OriginalPostComponent";
import { PostsGrid } from "../../Components/Posts-Grid-Component/PostsGrid";
import { CommentsComponent } from "../../Components/Comments-Component/CommentsComponent";

let commendata = [
  {
    name: "Rahul Darekar",
    profileImg:
      "https://helpx.adobe.com/content/dam/help/en/photoshop/using/convert-color-image-black-white/jcr_content/main-pars/before_and_after/image-before/Landscape-Color.jpg",
    comment:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis sed ultrices dui amet. Quis vivamus magna iaculis quis nunc.",
    date: "Yesterday"
  },
  {
    name: "Rahul Darekar",
    profileImg:
      "https://helpx.adobe.com/content/dam/help/en/photoshop/using/convert-color-image-black-white/jcr_content/main-pars/before_and_after/image-before/Landscape-Color.jpg",
    comment:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis sed ultrices dui amet. Quis vivamus magna iaculis quis nunc.",
    date: "Yesterday"
  },
  {
    name: "Rahul Darekar",
    profileImg:
      "https://helpx.adobe.com/content/dam/help/en/photoshop/using/convert-color-image-black-white/jcr_content/main-pars/before_and_after/image-before/Landscape-Color.jpg",
    comment:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis sed ultrices dui amet. Quis vivamus magna iaculis quis nunc.",
    date: "Yesterday"
  }
];
class Similarposts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      images: []
    };
  }

  componentDidMount() {
    fetch(
      "https://api.unsplash.com/search/photos?page=1&query=memes&client_id=VWqoQMxZ9HouNUurF3bTSfd8uJTTIdV6z33X3C8qaYE"
    )
      .then(res => res.json())
      .then(ress => {
        ress.results.forEach(img => {
          let obj = {
            user: {
              name: img.user.username,
              profileimg: img.user.profile_image.small
            },
            post: {
              title: img.alt_description
                ? img.alt_description.split(" ")[0] +
                  " " +
                  img.alt_description.split(" ")[1]
                : "Major things",
              about: img.description,
              spaeciallyfor: "funbook users",
              posts: [img.urls.regular]
            }
          };
          this.setState({ images: [...this.state.images, obj] });
        });
      });
  }

  render() {
    return (
      <div className="funbook_similarposts_container">
        <div className="funbook_similarposts_subcontainer">
          <div className="section1">
            {this.state.images.length > 0 ? (
              <OriginalPostComponent postInfo={this.state.images[0]} />
            ) : (
              <div></div>
            )}
            <div className="funbook_comments_container">
              <div className="funbook_comments_subcontainer">
                <h5>People Views</h5>
                <br />
              </div>
              <div>
                {commendata.map(items => {
                  return <CommentsComponent commentInfo={items} />;
                })}
              </div>
            </div>
          </div>
          <div className="section2">
            <PostsGrid />
          </div>
        </div>
      </div>
    );
  }
}

export { Similarposts };
