import React, { Component } from "react";
import "./ExplorePage.scss";
import { PostsGrid } from "../../Components/Posts-Grid-Component/PostsGrid";
import { SubscribersList } from "../../Components/Subscibers-List-Component/SubcribersList";

class ExplorePage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="funbook_explore_main_container">
        <div className="funbook_explore_main_subcontainer">
          <div className="section1">
            <SubscribersList />
          </div>
          <div className="section2">
            <PostsGrid />
          </div>
        </div>
      </div>
    );
  }
}

export { ExplorePage };
