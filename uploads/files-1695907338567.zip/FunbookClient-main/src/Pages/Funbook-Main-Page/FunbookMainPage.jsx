import React, { Component } from "react";
import "./FunbookMainPage.scss";
import { LoginPage } from "../Login-Page/LoginPage";
import { ExplorePage } from "../Explore-Page-Component/ExplorePage";
import { ProfilePage } from "../Profile-Page/ProfilePage";
import { TopicPage } from "../TopicProfile-Page/TopicProfilePage";
import { Similarposts } from "../SimilarPosts-Page/SimilarpostsPage";
import { TopicsPage } from "../Topics-Page-Component/TopicsPageComponent";
import { Header } from "../../Components/Header-Component/Header";

class FunbookMainPage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div>
        <div className="funbook_mail_component_with_header">
          <div className="funbook_mail_component_with_subheader">
            <Header />
          </div>
        </div>
        <div className="funbook_main_container">
          <div className="funbook_main_subcontainer">
            <div className="funbook_app_section_container">
              <TopicPage />
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export { FunbookMainPage };
