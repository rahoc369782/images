import React, { Component } from "react";
import "./LoginPage.scss";
import login_intro from "../../Assets/Svg/login-intro-img.svg";
import { InputComponent } from "../../SmallComponents/Input-Component/InputComponent";
import { ButtonComponent } from "../../SmallComponents/Button-Component/ButtonComponent";
import { GoogleLoginComponent } from "../../SmallComponents/Google-Login-Component/GoogleLoginComponent";

class LoginPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: ""
    };
  }

  handleEmail = email => {
    this.setState({ email });
  };

  loginUser = () => {};

  handleUserWithGoogle = () => {};

  render() {
    return (
      <div className="funbook_login_container">
        <div className="funbook_login_subcontainer">
          <div className="funbook_login_intro">
            <h3 onClick={() => document.body.classList.toggle("dark-mode")}>
              funbook
              <span> for you</span>
            </h3>
            <span>Fillings and thoughts of people in new way</span>
          </div>

          <div className="funbook_login_main_section">
            <div className="funbook_login_main_subsection">
              <img
                alt="login_intro"
                className="login_intro_img"
                src={login_intro}
              />
              <div className="funbook_login_input_container">
                <InputComponent
                  title="Enter email here..."
                  fun={this.handleEmail}
                  value={this.state.email}
                />
                <ButtonComponent
                  title="Verify"
                  fun={this.loginUser}
                  color="inherit"
                />
                <div className="login_devider">
                  <h4
                    style={{ textAlign: "center", margin: "20px 0px 20px 0px" }}
                  >
                    OR
                  </h4>
                </div>
                <GoogleLoginComponent fun={this.handleUserWithGoogle} />
                <GoogleLoginComponent fun={this.handleUserWithGoogle} />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export { LoginPage };
