import React, { Component } from "react";
import "./TopicsPageComponent.scss";
import { TopicsGrid } from "../../Components/Topics-Grid-Component/TopicsGridComponent";
import { TopicsAddedList } from "../../Components/Topics-Added-Component/TopicsAddedComponent";

class TopicsPage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="funbook_explore_main_container">
        <div className="funbook_explore_main_subcontainer">
          <div className="section1">
            <TopicsAddedList />
          </div>
          <div className="section2">
            <TopicsGrid />
          </div>
        </div>
      </div>
    );
  }
}

export { TopicsPage };
