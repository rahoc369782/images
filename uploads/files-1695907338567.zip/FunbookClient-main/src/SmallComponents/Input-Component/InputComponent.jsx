import "./InputComponent.scss";

const InputComponent = ({ title, fun, value }) => {
  return (
    <div className="funbook_input_container">
      <input
        value={value}
        placeholder={title}
        onChange={e => (fun ? fun(e.target.value) : null)}
      />
    </div>
  );
};

export { InputComponent };
