import "./ProfileWithName.scss";
import { ButtonComponent } from "../Button-Component/ButtonComponent";
import { DemandedAvtaar } from "../Demanded-Avtaar-Component/DemandedAvtaarComponent";

const ProfileNameComponent = ({ profileData }) => {
  console.log(profileData);
  let { name, profile, bio, subcribers, posts } = profileData;
  return (
    <div className="profile_container">
      <div className="profile_subcontainer">
        <div className="prifile_btn_container">
          <ButtonComponent title="subscribe" />
        </div>

        <div className="profile_data_container">
          <div className="prifile_img">
            <DemandedAvtaar size="95px" url={profile} />
          </div>
          <div className="prifile_meta">
            <span>{name}</span>
            <p>{bio}</p>
            <div className="profile_stats_part">
              <label>
                Subcribers{" "}
                <span style={{ fontWeight: 600 }}> {subcribers}</span>
              </label>
              <br />
              <label>
                Posts <span style={{ fontWeight: 600 }}> {posts}</span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export { ProfileNameComponent };
