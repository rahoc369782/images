import React, { Component } from "react";
import "./TopicProfileComponent.scss";
import { PostsGrid } from "../../Components/Posts-Grid-Component/PostsGrid";
import { TopicNameComponent } from "../Topic-Name-Component/TopicNameComponent";

class TopicProfileComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="funbook_explore_main_container">
        <div className="funbook_explore_main_subcontainer">
          <div className="section1">
            <TopicNameComponent
              profileData={{
                name: "Kevin Novels",
                bio:
                  "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eu aliquam tincidunt urna dictumst nisl et. Sed porttitor.",
                subcribers: "200k",
                posts: 100,
                profile:
                  "https://www.bitmoji.com/img/2a852af8.bfg-tiles.cache.png"
              }}
            />
          </div>
        </div>
      </div>
    );
  }
}

export { TopicProfileComponent };
