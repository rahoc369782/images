import React, { useState } from "react";
import "./GoogleLoginComponent.scss";
import google from "../../Assets/Svg/google.svg";
import { GoogleLogin } from "react-google-login";

const GoogleLoginComponent = ({ fun }) => {
  const [loginProcess, setLoginProcess] = useState(false);
  console.log(process.env);
  return (
    <div
      onClick={() => (fun ? fun() : null)}
      className="funbook_google_login_container"
    >
      <GoogleLogin
        clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}
        onSuccess={v => console.log(v)}
        onFailure={null}
        render={renderProps => (
          <div>
            {loginProcess === false ? (
              <div
                onClick={renderProps.onClick}
                disabled={renderProps.disabled}
                className="funbook_google_login_subcontainer"
              >
                <img src={google} alt="google" />
                <h5>Continue With Google</h5>
              </div>
            ) : loginProcess === "progress" ? (
              <div class="login_button">
                <span
                  style={{
                    color: "dodgerblue",
                    fontWeight: 500,
                    fontSize: 16
                  }}
                >
                  Logging you in...
                </span>
              </div>
            ) : (
              <div class="login_button">
                <span
                  style={{
                    color: "green",
                    fontWeight: 500,
                    fontSize: 16
                  }}
                >
                  Welcome {this.context.state.user.name}
                </span>
              </div>
            )}
          </div>
        )}
        cookiePolicy={"single_host_origin"}
      />
    </div>
  );
};

export { GoogleLoginComponent };
