import "./CircleGeneratorComponent.scss";

const CircleGeneratorComponent = ({ image }) => {
  return <div></div>;
};

export { CircleGeneratorComponent };
