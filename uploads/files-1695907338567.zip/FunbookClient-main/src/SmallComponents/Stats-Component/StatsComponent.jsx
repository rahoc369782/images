import "./StatsComponent.scss";

const StatsComponent = ({ data }) => {
  return (
    <div className="stats_section_container">
      <div className="stats_section_subcontainer">
        <div className="upvote_container">
          <ion-icon name="arrow-up-outline"></ion-icon>
          <span>{data.upvotes}</span>
        </div>
        <div className="comment_container">
          <ion-icon name="happy-outline"></ion-icon>
          <span>{data.comments}</span>
        </div>
        <div className="smiles_container">
          <ion-icon name="chatbox-outline"></ion-icon>
          <span>{data.smiles}</span>
        </div>
      </div>
    </div>
  );
};

export { StatsComponent };
