const DemandedAvtaar = ({ url, size, shape }) => {
  console.log(shape);
  return (
    <img
      alt="demanded"
      style={{
        width: size,
        cursor: "pointer",
        height: size,
        borderRadius: shape ? 10 : 100,
        border: "2px solid white"
      }}
      src={url}
    />
  );
};

export { DemandedAvtaar };
