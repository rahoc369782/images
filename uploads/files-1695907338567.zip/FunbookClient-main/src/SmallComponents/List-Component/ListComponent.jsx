import "./ListComponent.scss";
import { DemandedAvtaar } from "../Demanded-Avtaar-Component/DemandedAvtaarComponent";
import { InputComponent } from "../Input-Component/InputComponent";

const ListComponent = ({ data, fun, shape }) => {
  console.log(shape);
  return (
    <div className="list_main_container">
      <div>
        <label>Your Favourites</label>
      </div>
      <div className="list_main_subcontainer">
        <div className="list_search_container">
          {<InputComponent title="search here..." />}
        </div>

        {data.map(items => {
          return (
            <div
              onClick={() => (fun ? fun() : null)}
              className="list_section_container"
            >
              <div className="list_section_first">
                <div className="web_view_avtaar">
                  <DemandedAvtaar
                    shape={shape}
                    size="25px"
                    url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuiuiYY--ENGKHCxoshOIavDEMIyHjKkpARw&usqp=CAU"
                  />
                </div>
                <div className="mobile_view_avtaar">
                  <DemandedAvtaar
                    size="55px"
                    shape={shape}
                    url="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSuiuiYY--ENGKHCxoshOIavDEMIyHjKkpARw&usqp=CAU"
                  />
                </div>
                <div className="list_section_name">{items.name}</div>
                <div className="list_section_mob_name">
                  {items.name.split(" ")[0]}
                </div>
              </div>
              {items.updates > 0 ? (
                <div className="list_section_second">
                  <h5>{items.updates}</h5>
                </div>
              ) : (
                <div></div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export { ListComponent };
