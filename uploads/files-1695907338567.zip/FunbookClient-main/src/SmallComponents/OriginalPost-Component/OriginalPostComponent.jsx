import { CardComponent } from "../../Components/Card-Component/CardComponent";
import "./OriginalPostComponent.scss";

const OriginalPostComponent = ({ postInfo }) => {
  return (
    <div className="original_component_container">
      <div className="original_component_subcontainer">
        <CardComponent postInfo={postInfo} />
      </div>
    </div>
  );
};

export { OriginalPostComponent };
