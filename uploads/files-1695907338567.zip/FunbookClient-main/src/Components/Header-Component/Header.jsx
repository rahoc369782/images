import "./Header.scss";
import React, { Component } from "react";
import { InputComponent } from "../../SmallComponents/Input-Component/InputComponent";
import { ButtonComponent } from "../../SmallComponents/Button-Component/ButtonComponent";
import { DemandedAvtaar } from "../../SmallComponents/Demanded-Avtaar-Component/DemandedAvtaarComponent";
import search from "../../Assets/Svg/search.svg";

class Header extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="funbook_header_main_component">
        <div className="funbook_header_main_subcomponent">
          <div className="header_brand_name">
            <h3 onClick={() => document.body.classList.toggle("dark-mode")}>
              funbook
            </h3>
          </div>
          <div className="header_section_container">
            <div className="header_section_subcontainer">
              <label>Explore</label>
              <br />
              <label>Topics</label>
            </div>
          </div>
          <div className="header_searchbar_container_mobile">
            <ion-icon name="search-outline"></ion-icon>
          </div>
          <div className="header_searchbar_container">
            <InputComponent title="Explore funbook topics , profiles and titles here..." />
          </div>
          <div className="header_addpost_container">
            <ButtonComponent title="Add Fun" />
          </div>
          <div className="header_userprofile_container">
            <DemandedAvtaar
              size="30px"
              url="https://images.unsplash.com/photo-1541700513212-79f419c0221d?ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=870&q=80"
            />
          </div>
        </div>
      </div>
    );
  }
}

export { Header };
