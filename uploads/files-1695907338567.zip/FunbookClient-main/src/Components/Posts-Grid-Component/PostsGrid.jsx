import "./PostsGrid.scss";
import React, { Component } from "react";
import { CardComponent } from "../../Components/Card-Component/CardComponent";

class PostsGrid extends Component {
  constructor(props) {
    super(props);
    this.state = {
      images: []
    };
  }

  componentDidMount() {
    fetch(
      "https://api.unsplash.com/search/photos?page=1&query=memes&client_id=VWqoQMxZ9HouNUurF3bTSfd8uJTTIdV6z33X3C8qaYE"
    )
      .then(res => res.json())
      .then(ress => {
        ress.results.forEach(img => {
          let obj = {
            user: {
              name: img.user.username,
              profileimg: img.user.profile_image.small
            },
            post: {
              title: img.alt_description
                ? img.alt_description.split(" ")[0] +
                  " " +
                  img.alt_description.split(" ")[1]
                : "Major things",
              about: img.description,
              spaeciallyfor: "funbook users",
              posts: [img.urls.regular]
            }
          };
          this.setState({ images: [...this.state.images, obj] });
        });
      });
  }
  render() {
    return (
      <div className="funbook_postsgrid_main_component">
        <div className="grid_section_header">
          <h4>For You</h4>
        </div>
        <div className="funbook_postsgrid_main_subcomponent">
          {this.state.images.map(img => {
            return (
              <div>
                <CardComponent postInfo={img} />
              </div>
            );
          })}
        </div>
      </div>
      //   <div class="pin_container">
      //     <div class="card card_small"></div>
      //     <div class="card card_medium"></div>
      //     <div class="card card_large"></div>
      //     <div class="card card_medium"></div>
      //     <div class="card card_small"></div>
      //     <div class="card card_large"></div>
      //     <div class="card card_medium"></div>
      //     <div class="card card_small"></div>
      //     <div class="card card_medium"></div>
      //     <div class="card card_small"></div>
      //     <div class="card card_medium"></div>
      //     <div class="card card_large"></div>
      //     <div class="card card_medium"></div>
      //     <div class="card card_small"></div>
      //     <div class="card card_medium"></div>
      //     <div class="card card_large"></div>
      //   </div>
    );
  }
}

export { PostsGrid };
