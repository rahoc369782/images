import "./TopicsCardComponent.scss";

const TopicsCard = ({ topicInfo }) => {
  let { profileImg, about, name, createdby, createdat, stats } = topicInfo;
  console.log(profileImg, topicInfo);
  return (
    <div className="topics_card_container">
      <div className="topics_card_subcontainer">
        <div className="topics_card_img_container">
          <img src={profileImg} />
        </div>
        <div className="topics_card_info_container">
          <h5>{name}</h5>
          <p>{about}</p>
        </div>
        <div className="topics_card_stats_container">
          <span>
            {`${stats.posts} Posts in Naruto magic & ${stats.adders} people added
            it.`}
          </span>
        </div>
      </div>
    </div>
  );
};

export { TopicsCard };
