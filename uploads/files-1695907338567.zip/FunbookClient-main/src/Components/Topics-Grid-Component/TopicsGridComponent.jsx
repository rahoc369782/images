import React, { Component } from "react";
import "./TopicsGridComponent.scss";
import { TopicsCard } from "../Topics-Card-Component/TopicsCardComponent";

//profileImg, about, name, createdby, createdat, stats
let testData = [
  {
    profileImg:
      "https://static.bandainamcoent.eu/high/naruto/naruto-suns-revolution/00-page-setup/nsr_game-thumbnail.jpg",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tempus ut egestas neque felis diam.",
    name: "Naruto Fans",
    createdby: "rahoc369782",
    createdat: "",
    stats: {
      adders: "20k",
      posts: "200k"
    }
  },
  {
    profileImg:
      "https://static.bandainamcoent.eu/high/naruto/naruto-suns-revolution/00-page-setup/nsr_game-thumbnail.jpg",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tempus ut egestas neque felis diam.",
    name: "Naruto Fans",
    createdby: "rahoc369782",
    createdat: "",
    stats: {
      adders: "20k",
      posts: "200k"
    }
  },
  {
    profileImg:
      "https://static.bandainamcoent.eu/high/naruto/naruto-suns-revolution/00-page-setup/nsr_game-thumbnail.jpg",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tempus ut egestas neque felis diam.",
    name: "Naruto Fans",
    createdby: "rahoc369782",
    createdat: "",
    stats: {
      adders: "20k",
      posts: "200k"
    }
  },
  {
    profileImg:
      "https://static.bandainamcoent.eu/high/naruto/naruto-suns-revolution/00-page-setup/nsr_game-thumbnail.jpg",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tempus ut egestas neque felis diam.",
    name: "Naruto Fans",
    createdby: "rahoc369782",
    createdat: "",
    stats: {
      adders: "20k",
      posts: "200k"
    }
  },
  {
    profileImg:
      "https://static.bandainamcoent.eu/high/naruto/naruto-suns-revolution/00-page-setup/nsr_game-thumbnail.jpg",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tempus ut egestas neque felis diam.",
    name: "Naruto Fans",
    createdby: "rahoc369782",
    createdat: "",
    stats: {
      adders: "20k",
      posts: "200k"
    }
  }
];

class TopicsGrid extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="topics_page_grid_container">
        <div className="topics_page_grid_subcontainer">
          <label>Trending Topics</label>
          <div className="topics_page_trending_container">
            {testData.map(items => {
              return <TopicsCard topicInfo={items} />;
            })}
          </div>
          <br />
          <br />
          <label>Explore or suggested Topics</label>
          <div className="topics_page_exploretopics_container">
            {testData.map(items => {
              return <TopicsCard topicInfo={items} />;
            })}
          </div>
        </div>
      </div>
    );
  }
}

export { TopicsGrid };
