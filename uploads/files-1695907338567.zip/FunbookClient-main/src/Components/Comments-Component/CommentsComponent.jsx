import React, { Component } from "react";
import "./CommentsComponent.scss";

class CommentsComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div className="comments_container">
        <div className="comments_subcontainer">
          <div className="comment_owner">
            <img src={this.props.commentInfo.profileImg} />
            <span>{this.props.commentInfo.name}</span>
          </div>
          <div className="comments">{this.props.commentInfo.comment}</div>
          <div className="comments_date">on {this.props.commentInfo.date}</div>
        </div>
      </div>
    );
  }
}

export { CommentsComponent };
