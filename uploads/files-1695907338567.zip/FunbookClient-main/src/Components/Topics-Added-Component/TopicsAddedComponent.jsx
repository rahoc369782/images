import React, { Component } from "react";
import { ListComponent } from "../../SmallComponents/List-Component/ListComponent";

const testdata = [
  { name: "Rahul Darekar", updates: 0 },
  { name: "Alex Dron", updates: 0 },
  { name: "Elon Musk", updates: 4 },
  { name: "Pavel Durov", updates: 0 },
  { name: "Radhe Radhe", updates: 0 },
  { name: "Radhe Mahadev", updates: 10 },
  { name: "Alex Dron", updates: 0 },
  { name: "Elon Musk", updates: 4 },
  { name: "Pavel Durov", updates: 0 },
  { name: "Radhe Radhe", updates: 0 },
  { name: "Radhe Mahadev", updates: 10 }
];
class TopicsAddedList extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="funbook_subscribers_main_component">
        <div className="funbook_subscribers_main_subcomponent">
          <ListComponent shape="s" data={testdata} />
        </div>
      </div>
    );
  }
}

export { TopicsAddedList };
