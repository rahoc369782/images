import "./CardComponent.scss";
import React, { Component } from "react";
import { DemandedAvtaar } from "../../SmallComponents/Demanded-Avtaar-Component/DemandedAvtaarComponent";
import { StatsComponent } from "../../SmallComponents/Stats-Component/StatsComponent";

class CardComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      images: []
    };
  }

  render() {
    return (
      <div className="card_cub_container">
        <div className="card_cub_subcontainer">
          <div className="card_owner_section">
            <DemandedAvtaar
              size="28px"
              url={this.props.postInfo.user.profileimg}
            />
            <div style={{ paddingLeft: 7 }}>
              <span>{this.props.postInfo.user.name}</span>
              <div className="one_word_title">
                {this.props.postInfo.post.title}
              </div>
            </div>
          </div>
          {/* post meta data */}
          <div className="card_meta_section_speciallyfor">
            {this.props.postInfo.post.spaeciallyfor ? (
              <span>{this.props.postInfo.post.spaeciallyfor}</span>
            ) : (
              <div></div>
            )}
          </div>
          <div className="card_meta_section_about">
            {this.props.postInfo.post.about ? (
              <span>{this.props.postInfo.post.about}</span>
            ) : (
              <div></div>
            )}
          </div>
          <div className="card_meta_section_post">
            <img
              style={{ borderRadius: 10, width: "100%" }}
              src={this.props.postInfo.post.posts[0]}
            />
          </div>
          <div className="card_meta_section_stats">
            <StatsComponent
              data={{ upvotes: "100", comments: "20k", smiles: "50k" }}
            />
          </div>
        </div>
      </div>
    );
  }
}

export { CardComponent };
